import sys
import os
import yaml
from pathlib import Path
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                           QHBoxLayout, QPushButton, QLabel, QProgressBar, 
                           QCheckBox, QSpinBox, QComboBox, QFileDialog, 
                           QTextEdit, QGroupBox, QFrame)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QIcon, QFont, QPalette, QColor
from garbage_collector import GarbageCollector
from loguru import logger

class GarbageCollectorThread(QThread):
    progress = pyqtSignal(str)
    finished = pyqtSignal()
    error = pyqtSignal(str)

    def __init__(self, config_path):
        super().__init__()
        self.config_path = config_path

    def run(self):
        try:
            # Load config
            with open(self.config_path, 'r') as f:
                config = yaml.safe_load(f)
            
            # Initialize collector with config
            collector = GarbageCollector(self.config_path)
            collector.config = config  # Override config with loaded values
            
            # Run cleanup
            collector.run()
            self.finished.emit()
        except Exception as e:
            self.error.emit(str(e))

class ModernButton(QPushButton):
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QPushButton:pressed {
                background-color: #0D47A1;
            }
        """)

class ModernCheckBox(QCheckBox):
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.setStyleSheet("""
            QCheckBox {
                color: white;
                font-weight: bold;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
                background-color: #333;
                border: 1px solid #666;
                border-radius: 3px;
            }
            QCheckBox::indicator:checked {
                background-color: #2196F3;
            }
        """)

class ModernSpinBox(QSpinBox):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("""
            QSpinBox {
                padding: 5px;
                border: 1px solid #666;
                border-radius: 4px;
                background-color: #333;
                color: white;
            }
            QSpinBox::up-button, QSpinBox::down-button {
                background-color: #444;
                border: none;
            }
            QSpinBox::up-button:hover, QSpinBox::down-button:hover {
                background-color: #555;
            }
        """)

class ModernComboBox(QComboBox):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("""
            QComboBox {
                padding: 5px;
                border: 1px solid #666;
                border-radius: 4px;
                background-color: #333;
                color: white;
            }
            QComboBox::drop-down {
                border: none;
                background-color: #444;
            }
            QComboBox::drop-down:hover {
                background-color: #555;
            }
        """)

class GarbageCollectorGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Garbage Collector")
        self.setMinimumSize(800, 600)
        self.setup_ui()
        self.load_config()

    def setup_ui(self):
        # Create central widget and main layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setSpacing(20)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # Title
        title = QLabel("Garbage Collector")
        title.setFont(QFont("Arial", 24, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("color: white;")
        main_layout.addWidget(title)

        # Settings Group
        settings_group = QGroupBox("Settings")
        settings_group.setStyleSheet("""
            QGroupBox {
                color: white;
                font-weight: bold;
                border: 1px solid #666;
                border-radius: 6px;
                margin-top: 6px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 3px;
            }
        """)
        settings_layout = QVBoxLayout()
        
        # Config file selection
        config_layout = QHBoxLayout()
        self.config_path = QLabel("src/config.yaml")  # Updated default path
        self.config_path.setStyleSheet("color: white;")
        config_button = ModernButton("Select Config")
        config_button.clicked.connect(self.select_config)
        config_layout.addWidget(QLabel("Config File:", styleSheet="color: white;"))
        config_layout.addWidget(self.config_path)
        config_layout.addWidget(config_button)
        settings_layout.addLayout(config_layout)

        # Options
        self.dry_run = ModernCheckBox("Dry Run Mode")
        self.backup_enabled = ModernCheckBox("Enable Backups")
        self.skip_system = ModernCheckBox("Skip System Files")
        self.skip_hidden = ModernCheckBox("Skip Hidden Files")
        
        options_layout = QHBoxLayout()
        options_layout.addWidget(self.dry_run)
        options_layout.addWidget(self.backup_enabled)
        options_layout.addWidget(self.skip_system)
        options_layout.addWidget(self.skip_hidden)
        settings_layout.addLayout(options_layout)

        # Resource thresholds
        thresholds_layout = QHBoxLayout()
        thresholds_layout.addWidget(QLabel("Disk Threshold:", styleSheet="color: white;"))
        self.disk_threshold = ModernSpinBox()
        self.disk_threshold.setRange(0, 100)
        self.disk_threshold.setValue(90)
        self.disk_threshold.setSuffix("%")
        thresholds_layout.addWidget(self.disk_threshold)
        
        thresholds_layout.addWidget(QLabel("Memory Threshold:", styleSheet="color: white;"))
        self.memory_threshold = ModernSpinBox()
        self.memory_threshold.setRange(0, 100)
        self.memory_threshold.setValue(90)
        self.memory_threshold.setSuffix("%")
        thresholds_layout.addWidget(self.memory_threshold)
        
        settings_layout.addLayout(thresholds_layout)
        settings_group.setLayout(settings_layout)
        main_layout.addWidget(settings_group)

        # Progress section
        progress_group = QGroupBox("Progress")
        progress_group.setStyleSheet("""
            QGroupBox {
                color: white;
                font-weight: bold;
                border: 1px solid #666;
                border-radius: 6px;
                margin-top: 6px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 3px;
            }
        """)
        progress_layout = QVBoxLayout()
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: 1px solid #666;
                border-radius: 4px;
                text-align: center;
                background-color: #333;
                color: white;
            }
            QProgressBar::chunk {
                background-color: #2196F3;
            }
        """)
        progress_layout.addWidget(self.progress_bar)
        
        self.log_display = QTextEdit()
        self.log_display.setReadOnly(True)
        self.log_display.setStyleSheet("""
            QTextEdit {
                background-color: #1e1e1e;
                color: #e0e0e0;
                border: 1px solid #666;
                border-radius: 4px;
                padding: 5px;
                font-family: 'Consolas', monospace;
            }
        """)
        progress_layout.addWidget(self.log_display)
        
        progress_group.setLayout(progress_layout)
        main_layout.addWidget(progress_group)

        # Control buttons
        button_layout = QHBoxLayout()
        self.start_button = ModernButton("Start Cleanup")
        self.start_button.clicked.connect(self.start_cleanup)
        self.stop_button = ModernButton("Stop")
        self.stop_button.clicked.connect(self.stop_cleanup)
        self.stop_button.setEnabled(False)
        button_layout.addWidget(self.start_button)
        button_layout.addWidget(self.stop_button)
        main_layout.addLayout(button_layout)

        # Status bar
        self.statusBar().showMessage("Ready")
        self.statusBar().setStyleSheet("color: white; background-color: #333;")

    def load_config(self):
        try:
            config_path = Path(self.config_path.text())
            if not config_path.exists():
                self.log_display.append(f"Config file not found: {config_path}")
                return

            with open(config_path, 'r') as f:
                config = yaml.safe_load(f)
            
            # Update UI with config values
            if 'general' in config:
                self.dry_run.setChecked(config['general'].get('dry_run', True))
                self.backup_enabled.setChecked(config['general'].get('backup_enabled', True))
            
            if 'safety' in config:
                self.skip_system.setChecked(config['safety'].get('skip_system_files', True))
                self.skip_hidden.setChecked(config['safety'].get('skip_hidden_files', True))
            
            if 'cleanup_rules' in config and 'resource_thresholds' in config['cleanup_rules']:
                thresholds = config['cleanup_rules']['resource_thresholds']
                self.disk_threshold.setValue(thresholds.get('disk_usage_percent', 90))
                self.memory_threshold.setValue(thresholds.get('memory_usage_percent', 90))

            self.log_display.append("Configuration loaded successfully")
        except Exception as e:
            self.log_display.append(f"Error loading config: {e}")

    def select_config(self):
        file_name, _ = QFileDialog.getOpenFileName(
            self,
            "Select Config File",
            "",
            "YAML Files (*.yaml *.yml);;All Files (*.*)"
        )
        if file_name:
            self.config_path.setText(file_name)
            self.load_config()

    def start_cleanup(self):
        try:
            self.start_button.setEnabled(False)
            self.stop_button.setEnabled(True)
            self.progress_bar.setRange(0, 0)  # Indeterminate progress
            self.log_display.clear()
            
            # Load or create config
            config_path = Path(self.config_path.text())
            if not config_path.exists():
                self.log_display.append(f"Config file not found: {config_path}")
                return

            with open(config_path, 'r') as f:
                config = yaml.safe_load(f)
            
            # Update config with current settings
            if 'general' not in config:
                config['general'] = {}
            config['general']['dry_run'] = self.dry_run.isChecked()
            config['general']['backup_enabled'] = self.backup_enabled.isChecked()
            
            if 'safety' not in config:
                config['safety'] = {}
            config['safety']['skip_system_files'] = self.skip_system.isChecked()
            config['safety']['skip_hidden_files'] = self.skip_hidden.isChecked()
            
            if 'cleanup_rules' not in config:
                config['cleanup_rules'] = {}
            if 'resource_thresholds' not in config['cleanup_rules']:
                config['cleanup_rules']['resource_thresholds'] = {}
            
            config['cleanup_rules']['resource_thresholds']['disk_usage_percent'] = self.disk_threshold.value()
            config['cleanup_rules']['resource_thresholds']['memory_usage_percent'] = self.memory_threshold.value()
            
            # Save updated config
            with open(config_path, 'w') as f:
                yaml.dump(config, f, default_flow_style=False)
            
            self.log_display.append("Starting cleanup process...")
            
            # Start cleanup thread
            self.cleanup_thread = GarbageCollectorThread(str(config_path))
            self.cleanup_thread.progress.connect(self.update_progress)
            self.cleanup_thread.finished.connect(self.cleanup_finished)
            self.cleanup_thread.error.connect(self.cleanup_error)
            self.cleanup_thread.start()
            
        except Exception as e:
            self.log_display.append(f"Error starting cleanup: {e}")
            self.cleanup_finished()

    def stop_cleanup(self):
        if hasattr(self, 'cleanup_thread') and self.cleanup_thread.isRunning():
            self.cleanup_thread.terminate()
            self.cleanup_thread.wait()
            self.cleanup_finished()

    def update_progress(self, message):
        self.log_display.append(message)
        self.log_display.verticalScrollBar().setValue(
            self.log_display.verticalScrollBar().maximum()
        )

    def cleanup_finished(self):
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(100)
        self.statusBar().showMessage("Cleanup completed")

    def cleanup_error(self, error_message):
        self.log_display.append(f"Error: {error_message}")
        self.cleanup_finished()

def main():
    try:
        app = QApplication(sys.argv)
        
        # Set application style
        app.setStyle('Fusion')
        
        # Create dark palette
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(53, 53, 53))
        palette.setColor(QPalette.ColorRole.WindowText, Qt.GlobalColor.white)
        palette.setColor(QPalette.ColorRole.Base, QColor(25, 25, 25))
        palette.setColor(QPalette.ColorRole.AlternateBase, QColor(53, 53, 53))
        palette.setColor(QPalette.ColorRole.ToolTipBase, Qt.GlobalColor.white)
        palette.setColor(QPalette.ColorRole.ToolTipText, Qt.GlobalColor.white)
        palette.setColor(QPalette.ColorRole.Text, Qt.GlobalColor.white)
        palette.setColor(QPalette.ColorRole.Button, QColor(53, 53, 53))
        palette.setColor(QPalette.ColorRole.ButtonText, Qt.GlobalColor.white)
        palette.setColor(QPalette.ColorRole.BrightText, Qt.GlobalColor.red)
        palette.setColor(QPalette.ColorRole.Link, QColor(42, 130, 218))
        palette.setColor(QPalette.ColorRole.Highlight, QColor(42, 130, 218))
        palette.setColor(QPalette.ColorRole.HighlightedText, Qt.GlobalColor.black)
        app.setPalette(palette)
        
        window = GarbageCollectorGUI()
        window.show()
        
        # Properly handle application exit
        sys.exit(app.exec())
    except Exception as e:
        logger.error(f"Error in GUI: {e}")
        sys.exit(1) 