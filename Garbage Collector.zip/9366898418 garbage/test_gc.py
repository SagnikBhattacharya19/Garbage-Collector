import os
import time
from pathlib import Path
from datetime import datetime, timedelta
from garbage_collector import GarbageCollector
from loguru import logger

def setup_test_files():
    """Create test files with different ages and sizes."""
    test_dirs = ['test_cleanup/temp', 'test_cleanup/logs', 'test_cleanup/cache']
    
    # Create test directories
    for dir_path in test_dirs:
        Path(dir_path).mkdir(parents=True, exist_ok=True)
    
    # Create files to be cleaned up (older than 1 day)
    old_files = [
        ('test_cleanup/temp/test.tmp', 1, 1024),  # 1 day old, 1KB
        ('test_cleanup/logs/test.log', 2, 2048),  # 2 days old, 2KB
        ('test_cleanup/cache/test.cache', 3, 3072)  # 3 days old, 3KB
    ]
    
    # Create files that should not be cleaned up (recent)
    recent_files = [
        ('test_cleanup/temp/test1.tmp', 0.5, 1024),  # 12 hours old, 1KB
        ('test_cleanup/logs/test1.log', 0.25, 2048),  # 6 hours old, 2KB
        ('test_cleanup/cache/test1.cache', 0.1, 3072)  # 2.4 hours old, 3KB
    ]
    
    # Create all test files
    for file_path, age_days, size_bytes in old_files + recent_files:
        path = Path(file_path)
        path.write_bytes(b'0' * size_bytes)
        # Set file modification time
        mtime = time.time() - (age_days * 24 * 60 * 60)
        os.utime(path, (mtime, mtime))
        logger.info(f"Created test file: {file_path} (age: {age_days} days, size: {size_bytes} bytes)")

def verify_cleanup():
    """Verify that files were cleaned up correctly."""
    # Files that should be deleted
    should_be_deleted = [
        'test_cleanup/temp/test.tmp',
        'test_cleanup/logs/test.log',
        'test_cleanup/cache/test.cache'
    ]
    
    # Files that should remain
    should_remain = [
        'test_cleanup/temp/test1.tmp',
        'test_cleanup/logs/test1.log',
        'test_cleanup/cache/test1.cache'
    ]
    
    # Check files that should be deleted
    for file_path in should_be_deleted:
        path = Path(file_path)
        if path.exists():
            logger.error(f"File {file_path} was not deleted as expected")
        else:
            logger.info(f"File {file_path} was successfully deleted")
    
    # Check files that should remain
    for file_path in should_remain:
        path = Path(file_path)
        if not path.exists():
            logger.error(f"File {file_path} was incorrectly deleted")
        else:
            logger.info(f"File {file_path} was correctly preserved")

def main():
    try:
        logger.info("Setting up test files...")
        setup_test_files()
        
        logger.info("Running garbage collector...")
        gc = GarbageCollector("src/config.yaml")
        gc.run()
        
        logger.info("Verifying cleanup results...")
        verify_cleanup()
        
        logger.info("Test completed successfully")
    except Exception as e:
        logger.error(f"Error during test: {e}")

if __name__ == "__main__":
    main() 